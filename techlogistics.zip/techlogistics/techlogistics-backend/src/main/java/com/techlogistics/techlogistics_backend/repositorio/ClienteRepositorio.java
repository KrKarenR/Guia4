package com.techlogistics.techlogistics_backend.repositorio;

import com.techlogistics.techlogistics_backend.modelo.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClienteRepositorio extends JpaRepository<Cliente, Long> {
    
}
