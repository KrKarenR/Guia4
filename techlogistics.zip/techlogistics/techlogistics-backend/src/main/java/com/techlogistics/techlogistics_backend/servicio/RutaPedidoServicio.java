package com.techlogistics.techlogistics_backend.servicio;

import com.techlogistics.techlogistics_backend.modelo.RutaPedido;
import com.techlogistics.techlogistics_backend.repositorio.RutaPedidoRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RutaPedidoServicio {
    private final RutaPedidoRepositorio rutaPedidoRepositorio;

    public RutaPedidoServicio(RutaPedidoRepositorio rutaPedidoRepositorio) {
        this.rutaPedidoRepositorio = rutaPedidoRepositorio;
    }

    public List<RutaPedido> listarTodos() {
        return rutaPedidoRepositorio.findAll();
    }

    public Optional<RutaPedido> buscarPorId(Long id) {
        return rutaPedidoRepositorio.findById(id);
    }

    public RutaPedido guardar(RutaPedido rutaPedido) {
        return rutaPedidoRepositorio.save(rutaPedido);
    }

    public void eliminar(Long id) {
        rutaPedidoRepositorio.deleteById(id);
    }
}
