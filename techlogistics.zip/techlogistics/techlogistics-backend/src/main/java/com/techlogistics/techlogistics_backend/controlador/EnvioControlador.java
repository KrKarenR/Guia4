package com.techlogistics.techlogistics_backend.controlador;

import com.techlogistics.techlogistics_backend.modelo.Envio;
import com.techlogistics.techlogistics_backend.servicio.EnvioServicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/envios")
public class EnvioControlador {
    private final EnvioServicio envioServicio;

    public EnvioControlador(EnvioServicio envioServicio) {
        this.envioServicio = envioServicio;
    }

    @GetMapping
    public List<Envio> listarEnvios() {
        return envioServicio.listarEnvios();
    }

    @PostMapping
    public Envio guardarEnvio(@RequestBody Envio envio) {
        return envioServicio.guardarEnvio(envio);
    }

    @DeleteMapping("/{id}")
    public void eliminarEnvio(@PathVariable Long id) {
        envioServicio.eliminarEnvio(id);
    }
}
