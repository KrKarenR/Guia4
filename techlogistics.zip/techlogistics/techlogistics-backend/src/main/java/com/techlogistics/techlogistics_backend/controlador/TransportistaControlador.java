package com.techlogistics.techlogistics_backend.controlador;

import com.techlogistics.techlogistics_backend.modelo.Transportista;
import com.techlogistics.techlogistics_backend.servicio.TransportistaServicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transportistas")
public class TransportistaControlador {
    private final TransportistaServicio transportistaServicio;

    public TransportistaControlador(TransportistaServicio transportistaServicio) {
        this.transportistaServicio = transportistaServicio;
    }

    @GetMapping
    public List<Transportista> listarTransportistas() {
        return transportistaServicio.listarTransportistas();
    }

    @PostMapping
    public Transportista guardarTransportista(@RequestBody Transportista transportista) {
        return transportistaServicio.guardarTransportista(transportista);
    }

    @DeleteMapping("/{id}")
    public void eliminarTransportista(@PathVariable Long id) {
        transportistaServicio.eliminarTransportista(id);
    }
}
