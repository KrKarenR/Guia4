package com.techlogistics.techlogistics_backend.servicio;

import com.techlogistics.techlogistics_backend.modelo.Transportista;
import com.techlogistics.techlogistics_backend.repositorio.TransportistaRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TransportistaServicio {
    private final TransportistaRepositorio transportistaRepositorio;

    public TransportistaServicio(TransportistaRepositorio transportistaRepositorio) {
        this.transportistaRepositorio = transportistaRepositorio;
    }

    public List<Transportista> listarTransportistas() {
        return transportistaRepositorio.findAll();
    }

    public Transportista guardarTransportista(Transportista transportista) {
        return transportistaRepositorio.save(transportista);
    }

    public void eliminarTransportista(Long id) {
        transportistaRepositorio.deleteById(id);
    }
}
