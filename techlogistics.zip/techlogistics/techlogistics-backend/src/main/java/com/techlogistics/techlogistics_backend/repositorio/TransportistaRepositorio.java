package com.techlogistics.techlogistics_backend.repositorio;

import com.techlogistics.techlogistics_backend.modelo.Transportista;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransportistaRepositorio extends JpaRepository<Transportista, Long> {
    
}
