package com.techlogistics.techlogistics_backend.repositorio;

import com.techlogistics.techlogistics_backend.modelo.Envio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EnvioRepositorio extends JpaRepository<Envio, Long> {
    
}
