package com.techlogistics.techlogistics_backend.servicio;

import com.techlogistics.techlogistics_backend.modelo.Envio;
import com.techlogistics.techlogistics_backend.repositorio.EnvioRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EnvioServicio {
    private final EnvioRepositorio envioRepositorio;

    public EnvioServicio(EnvioRepositorio envioRepositorio) {
        this.envioRepositorio = envioRepositorio;
    }

    public List<Envio> listarEnvios() {
        return envioRepositorio.findAll();
    }

    public Envio guardarEnvio(Envio envio) {
        return envioRepositorio.save(envio);
    }

    public void eliminarEnvio(Long id) {
        envioRepositorio.deleteById(id);
    }
}
