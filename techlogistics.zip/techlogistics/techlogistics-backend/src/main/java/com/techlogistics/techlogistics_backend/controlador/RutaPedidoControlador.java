package com.techlogistics.techlogistics_backend.controlador;

import com.techlogistics.techlogistics_backend.modelo.RutaPedido;
import com.techlogistics.techlogistics_backend.servicio.RutaPedidoServicio;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rutas-pedido")
public class RutaPedidoControlador {
    private final RutaPedidoServicio rutaPedidoServicio;

    public RutaPedidoControlador(RutaPedidoServicio rutaPedidoServicio) {
        this.rutaPedidoServicio = rutaPedidoServicio;
    }

    @GetMapping
    public List<RutaPedido> listarRutas() {
        return rutaPedidoServicio.listarTodos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<RutaPedido> obtenerRuta(@PathVariable Long id) {
        return rutaPedidoServicio.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public RutaPedido crearRuta(@RequestBody RutaPedido rutaPedido) {
        return rutaPedidoServicio.guardar(rutaPedido);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RutaPedido> actualizarRuta(@PathVariable Long id, @RequestBody RutaPedido rutaPedido) {
        return rutaPedidoServicio.buscarPorId(id)
                .map(existente -> {
                    rutaPedido.setId(id);
                    return ResponseEntity.ok(rutaPedidoServicio.guardar(rutaPedido));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRuta(@PathVariable Long id) {
        if (rutaPedidoServicio.buscarPorId(id).isPresent()) {
            rutaPedidoServicio.eliminar(id);
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
