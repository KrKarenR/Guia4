const mapEl = document.getElementById('map');
const log = document.getElementById('trackingLog');
const envioInput = document.getElementById('envioId');
const btn = document.getElementById('subscribeBtn');
let map, marker, socket;

function initMap(){
  map = L.map('map').setView([4.5709, -74.2973], 6); // Colombia view
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19}).addTo(map);
}
initMap();

btn.addEventListener('click', () => {
  const envioId = envioInput.value.trim();
  if(!envioId) return alert('Ingresa un envio_id');
  if(socket) socket.disconnect();
  socket = io();
  socket.emit('subscribe_envio', envioId);
  socket.on('tracking_update', data => {
    const { latitud, longitud, timestamp, observacion } = data;
    const lat = parseFloat(latitud) || parseFloat(data.lat) || 4.6;
    const lng = parseFloat(longitud) || parseFloat(data.lng) || -74.0;
    if(!marker) marker = L.marker([lat,lng]).addTo(map);
    else marker.setLatLng([lat,lng]);
    map.setView([lat,lng], 13);
    const time = timestamp || new Date().toISOString();
    log.innerHTML = `<div class="item">[${time}] ${lat.toFixed(5)}, ${lng.toFixed(5)} - ${observacion || ''}</div>` + log.innerHTML;
  });
});

// demo: send random tracking updates when pressing map (only for local testing)
mapEl.addEventListener('click', (e) => {
  if(!socket) return;
  const latlng = map.mouseEventToLatLng(e);
  socket.emit('tracking', { envioId: envioInput.value, latitud: latlng.lat, longitud: latlng.lng, timestamp: new Date().toISOString(), observacion: 'Actualizado desde mapa' });
});
