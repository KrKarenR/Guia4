const pForm = document.getElementById('pedidoForm');
const pList = document.getElementById('pedidosList');
pForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const formData = new FormData(pForm);
  const data = {
    cliente_id: formData.get('clienteSelect') || document.getElementById('clienteSelect').value,
    direccion_envio: formData.get('direccion_envio') || pForm.querySelector('[name=direccion_envio]').value,
    observaciones: formData.get('observaciones') || ''
  };
  const res = await fetch('/api/pedidos', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
  await res.json();
  pForm.reset();
  loadPedidos();
});

async function loadPedidos(){
  const res = await fetch('/api/pedidos');
  const arr = await res.json();
  pList.innerHTML = arr.map(p => `<div class="item"><strong>#${p.pedido_id}</strong> — ${p.cliente_nombre} — ${p.direccion_envio}</div>`).join('');
  // ensure cliente select is populated by clientes.js
}
loadPedidos();
