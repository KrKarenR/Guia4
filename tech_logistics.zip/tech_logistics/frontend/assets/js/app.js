// small shared frontend behavior
console.log('TechLogistics frontend loaded');
