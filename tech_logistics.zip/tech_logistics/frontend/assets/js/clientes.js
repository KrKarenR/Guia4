const form = document.getElementById('clienteForm');
const list = document.getElementById('clientesList');
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  const res = await fetch('/api/clientes', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
  const json = await res.json();
  form.reset();
  loadClientes();
});
async function loadClientes(){
  const res = await fetch('/api/clientes');
  const arr = await res.json();
  list.innerHTML = arr.map(c => `<div class="item"><strong>${c.nombre}</strong> — ${c.email}</div>`).join('');
  const sel = document.getElementById('clienteSelect');
  if(sel){
    sel.innerHTML = '<option value="">Seleccione cliente</option>' + arr.map(c=>`<option value="${c.cliente_id}">${c.nombre}</option>`).join('');
  }
}
loadClientes();
