package com.techlogistics.techlogistics_backend.servicio;

import com.techlogistics.techlogistics_backend.modelo.Pedido;
import com.techlogistics.techlogistics_backend.repositorio.PedidoRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PedidoServicio {
    private final PedidoRepositorio pedidoRepositorio;

    public PedidoServicio(PedidoRepositorio pedidoRepositorio) {
        this.pedidoRepositorio = pedidoRepositorio;
    }

    public List<Pedido> listarPedidos() {
        return pedidoRepositorio.findAll();
    }

    public Pedido guardarPedido(Pedido pedido) {
        return pedidoRepositorio.save(pedido);
    }

    public void eliminarPedido(Long id) {
        pedidoRepositorio.deleteById(id);
    }
}
