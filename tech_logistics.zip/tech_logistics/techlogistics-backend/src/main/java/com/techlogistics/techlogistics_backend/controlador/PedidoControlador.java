package com.techlogistics.techlogistics_backend.controlador;

import com.techlogistics.techlogistics_backend.modelo.Pedido;
import com.techlogistics.techlogistics_backend.servicio.PedidoServicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoControlador {
    private final PedidoServicio pedidoServicio;

    public PedidoControlador(PedidoServicio pedidoServicio) {
        this.pedidoServicio = pedidoServicio;
    }

    @GetMapping
    public List<Pedido> listarPedidos() {
        return pedidoServicio.listarPedidos();
    }

    @PostMapping
    public Pedido guardarPedido(@RequestBody Pedido pedido) {
        return pedidoServicio.guardarPedido(pedido);
    }

    @DeleteMapping("/{id}")
    public void eliminarPedido(@PathVariable Long id) {
        pedidoServicio.eliminarPedido(id);
    }
}
